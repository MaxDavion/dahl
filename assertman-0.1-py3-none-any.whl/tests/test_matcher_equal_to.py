import pytest
from assertman.matchers import *
from assertman.objects import AssertableDict
from tests.utils import parse_exeption

""" Тесты на работу валидатор `equal_to` в схеме Cerberus  """

valid_json = {
    "id": 123456,
    "name": "Твой пакет услуг",
    "is_purchased": True,
    "devices": ["Android Device", "Apple Device", "Stb Device"],
    "raitings": {"kinopoisk": 8.9, "imdb": 9.1, "wink": 9.5}
}

invalid_json = {
    "id": 12346,
    "name": "Мой пакет услуг",
    "is_purchased": False,
    "devices": ["Apple Device", "Android Device", "Apple Device"],
    "raitings": {"kinopoisk": 9.9, "imdb": 9.1, "wink": 9.5}
}



@pytest.mark.parametrize("id, name, is_purchased, devices, raitings", [
    [i for i in valid_json.values()],
    [equal_to(i) for i in valid_json.values()],
    [is_(i) for i in valid_json.values()],
    [is_(equal_to(i)) for i in valid_json.values()],
    [not_(i) for i in invalid_json.values()],
    [not_(equal_to(i)) for i in invalid_json.values()],
    [is_(not_(i)) for i in invalid_json.values()],
    [is_(not_(equal_to(i))) for i in invalid_json.values()]
])
def test_equal_to_positive_and_with_not(doc_json, id, name, is_purchased, devices, raitings):
    """ Тесты на матчер позитивные и с отрицанием """
    assert doc_json('id').should(id)
    assert doc_json('name').should(name)
    assert doc_json('is_purchased').should(is_purchased)
    assert doc_json('devices').should(devices)
    # assert doc_json('raitings').should(raitings)

    assert doc_json.should(has_entries(id=id, name=name, is_purchased=is_purchased, devices=devices, raitings=raitings))
    assert doc_json.should(has_entries({"id": id, "name": name}, devices=devices))



@pytest.mark.parametrize("id, name, is_purchased, devices, raitings", [
    [i for i in invalid_json.values()],
    [equal_to(i) for i in invalid_json.values()],
    [is_(i) for i in invalid_json.values()],
    [is_(equal_to(i)) for i in invalid_json.values()],
])
def test_equal_to_with_raises(doc_json, id, name, is_purchased, devices, raitings):
    """ Тесты на выдачу ошибки матчером """

    def error_pattern(field):
        return f"{field}: Must be `{invalid_json[field]}`, but was `{valid_json[field]}`"

    # 1. r.(key).should(value): позитивные, одинарные ошибки
    for field, matcher in [
        ('id', id), ('name', name), ('is_purchased', is_purchased), ('devices', devices), ('raitings', raitings)
    ]:
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json(field).should(matcher)
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 1
        assert error_pattern(field) in exeptions[0]

    # 2. should(has_entries(key=value)): позитивные, несколько ошибок в выдаче
    with pytest.raises(AssertionError) as excinfo:
        assert doc_json.should(has_entries(id=id, name=name, is_purchased=is_purchased, devices=devices, raitings=raitings))
    exeptions = parse_exeption(excinfo)
    assert len(exeptions) == 5
    assert error_pattern('devices') in exeptions[0]
    assert error_pattern('id') in exeptions[1]
    assert error_pattern('is_purchased') in exeptions[2]
    assert error_pattern('name') in exeptions[3]
    assert error_pattern('raitings') in exeptions[4]

    # 3. should(has_entries({key: value})): позитивные, несколько ошибок в выдаче
    with pytest.raises(AssertionError) as excinfo:
        assert doc_json.should((has_entries({"id": id, "name": name}, devices=devices)))
    exeptions = parse_exeption(excinfo)
    assert len(exeptions) == 3
    assert error_pattern('devices') in exeptions[0]
    assert error_pattern('id') in exeptions[1]
    assert error_pattern('name') in exeptions[2]


@pytest.mark.parametrize("id, name, is_purchased, devices, raitings", [
    [not_(i) for i in valid_json.values()],
    [not_(equal_to(i)) for i in valid_json.values()],
    [is_(not_(i)) for i in valid_json.values()],
    [is_(not_(equal_to(i))) for i in valid_json.values()],
])
def test_equal_to_with_raises_with_not(doc_json, id, name, is_purchased, devices, raitings):
    """ Тесты на выдачу ошибки матчером (с отрицанием) """

    def error_pattern(field):
        return f"{field}: Must be not `{valid_json[field]}`, but was `{valid_json[field]}`"

    # 1. r.(key).should(value): негативные, одинарные ошибки
    for field, matcher in [
        ('id', id), ('name', name), ('is_purchased', is_purchased), ('devices', devices), ('raitings', raitings)
    ]:
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json(field).should(matcher)
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 1
        assert error_pattern(field) in exeptions[0]

    # 2. should(has_entries(key=value)): негативные, несколько ошибок в выдаче
    with pytest.raises(AssertionError) as excinfo:
        assert doc_json.should(has_entries(id=id, name=name, is_purchased=is_purchased, devices=devices, raitings=raitings))
    exeptions = parse_exeption(excinfo)
    assert len(exeptions) == 5
    assert error_pattern('devices') in exeptions[0]
    assert error_pattern('id') in exeptions[1]
    assert error_pattern('is_purchased') in exeptions[2]
    assert error_pattern('name') in exeptions[3]
    assert error_pattern('raitings') in exeptions[4]

    # 3. should(has_entries({key: value})): негативные, несколько ошибок в выдаче
    with pytest.raises(AssertionError) as excinfo:
        assert doc_json.should((has_entries({"id": id, "name": name}, devices=devices)))
    exeptions = parse_exeption(excinfo)
    assert len(exeptions) == 3
    assert error_pattern('devices') in exeptions[0]
    assert error_pattern('id') in exeptions[1]
    assert error_pattern('name') in exeptions[2]


def test_equal_to_with_mismatch_type(doc_json):
    """ Матрчер проверяет не совпадение типа """
    with pytest.raises(AssertionError) as excinfo:
        assert doc_json.should(has_entries(id='123456'))
    exeptions = parse_exeption(excinfo)
    assert len(exeptions) == 1
    assert "id: Type mismatch. Must be `123456` (str), but was `123456` (int)" in exeptions[0]


def test_equal_to_with_mismatch_type_with_not(doc_json):
    """ Матрчер проверяет не совпадение типа: при провеке с отрицанием совпадение типа все равно проверяется
    Это значит, что проверка: '123456' не равно <123456>, должно выдать  ошибку `Type mismatch`.
    Даже не смотря на то, что с точки зрения логики оно корректное.
    """
    with pytest.raises(AssertionError) as excinfo:
        assert doc_json.should(has_entries(id=not_('123456')))
    exeptions = parse_exeption(excinfo)
    assert len(exeptions) == 1
    assert "id: Type mismatch. Must be not `123456` (str), but was `123456` (int)" in exeptions[0]


def test_equal_to_with_boolean_true_not_equal_integer_one(doc_json):
    """ Матрчер проверяет не совпадение типа, считая что 1 не равен True """
    with pytest.raises(AssertionError) as excinfo:
        assert doc_json.should(has_entries(is_purchased=1))
    exeptions = parse_exeption(excinfo)
    assert len(exeptions) == 1
    assert "is_purchased: Type mismatch. Must be `1` (int), but was `True` (bool)" in exeptions[0]


