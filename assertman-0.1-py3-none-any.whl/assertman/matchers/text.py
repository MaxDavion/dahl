import hamcrest


matches_regexp = hamcrest.matches_regexp
equal_to_ignoring_case = hamcrest.equal_to_ignoring_case
equal_to_ignoring_whitespace = hamcrest.equal_to_ignoring_whitespace
contains_string = hamcrest.contains_string
ends_with = hamcrest.ends_with
starts_with = hamcrest.starts_with
string_contains_in_order = hamcrest.string_contains_in_order
