import hamcrest


all_of = hamcrest.all_of
any_of = hamcrest.any_of
not_ = hamcrest.not_