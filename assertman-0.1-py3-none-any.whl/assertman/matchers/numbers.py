import hamcrest


close_to = hamcrest.close_to
greater_than = hamcrest.greater_than
greater_than_or_equal_to = hamcrest.greater_than_or_equal_to
less_than = hamcrest.less_than
less_than_or_equal_to = hamcrest.less_than_or_equal_to
