import hamcrest

has_entries = hamcrest.has_entries
has_key = hamcrest.has_key

