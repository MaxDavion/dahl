from assertman.assertable_mixin import AssertableMixin
from requests import Session, Response


class AssertableResponse(Response, AssertableMixin):

    def __init__(self, origin_responce):
        super(AssertableResponse, self).__init__()
        for k, v in origin_responce.__dict__.items():
            self.__dict__[k] = v

    @property
    def _assertable_data(self):
        return self.json()

    def __call__(self, query):
        return self.__class__(self).extract(query)
