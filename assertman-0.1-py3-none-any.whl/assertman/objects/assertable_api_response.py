from assertman.assertable_mixin import AssertableMixin
from requests import Session, Response


class AssertableResponse(Response, AssertableMixin):

    def __init__(self, origin_responce):
        super(AssertableResponse, self).__init__()
        for k, v in origin_responce.__dict__.items():
            self.__dict__[k] = v

    @property
    def _assertable_data(self):
        return self.json()

    def __call__(self, query):
        return self.__class__(self).extract(query)


#     def __call__(self, query: str):
#         if query.startswith('$'):
#             document = jsonpath_get_one(self.json(), query)
#             new = self.__class__(self)
#             new._document = document
#         else:
#             assert query in self.json(), f"В теле ответа нет ключа `{query}`"
#             new = self.__class__(self)
#             new._document = self.json()
#             new.offset = query
#         return new
