import hamcrest
from hamcrest.core.base_matcher import BaseMatcher
from assertman import cerberus_wrapper
from assertman import objects


# __tracebackhide__ = True


class AssertableMixin:

    _assertion_processing = None

    @property
    def _assertable_data(self):
        raise NotImplementedError(
            'Что бы добавить объекту свойство `assertable`, определите в нем метод `_assertable_data`')

    def should(self, matcher):
        if not isinstance(matcher, BaseMatcher):
            raise TypeError(f'Переданный матчер имеет неподдерживаемый тип {type(matcher)}')

        # временный костыль в связи с тем что has_key не работает с cerberus
        if type(matcher).__name__ in ['IsDictContainingEntries']:
            cerberus_wrapper.assert_that(self._assertable_data, matcher)
        else:
            hamcrest.assert_that(self._assertable_data, matcher)
        return True

    def filter(self, **kwargs):
        if not isinstance(self._assertable_data, list):
            raise ValueError("Фильтрация доступна только для списков")

        result = []
        for key, value in kwargs.items():
            result = [item for item in self._assertable_data if item.get(key) == value]
        obj = objects.make_assertable_object(result)
        obj._assertion_processing = "hamcrest"
        return obj

    def find(self, **kwargs):
        if not isinstance(self._assertable_data, list):
            raise ValueError("Фильтрация доступна только для списков")

        result = []
        for key, value in kwargs.items():
            result = [item for item in self._assertable_data if item.get(key) == value]

        if len(result) > 1:
            raise ValueError('В резултате фильтрации найдено больше однного совпадения')

        obj = objects.make_assertable_object(result[0])
        obj._assertion_processing = "hamcrest"
        return obj

    def extract(self, query):
        if not isinstance(self._assertable_data, dict):
            raise ValueError("Извлечение доступна только для словарей")

        if not self._assertable_data.get(query):
            raise ValueError(f"ключ {query} не найден в словаре")

        obj = objects.make_assertable_object(self._assertable_data[query])
        obj._assertion_processing = "hamcrest"
        return obj
