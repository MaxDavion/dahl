import requests
from cerberus_assertion.objects.assertable_api_response import AssertableResponse
from cerberus_assertion.matchers import *


def get_data():
    r = requests.post(
        url="https://jsonplaceholder.typicode.com/posts",
        json={"name": "qwerty", "age": 45, "devise": {"apple": 250, "android": 230}}
    )
    return AssertableResponse(r)


def test_req():
    r = get_data()
    r.should(has_entries(name="qwerty"))

def test_req_with_extraction():
    r = get_data()
    r("devise").should(has_entries(apple=250))






