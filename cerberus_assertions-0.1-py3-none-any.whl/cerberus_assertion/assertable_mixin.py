import hamcrest
from cerberus_assertion import objects


class AssertableMixin:

    @property
    def assertable_data(self):
        return self.document


    def should(self, matcher):
        hamcrest.assert_that(self.assertable_data, matcher)
        return True

    def filter(self, **kwargs):
        if not isinstance(self.assertable_data, list):
            raise ValueError("Фильтрация доступна только для списков")

        result = []
        for key, value in kwargs.items():
            result = [item for item in self.assertable_data if item.get(key) == value]
        return objects.make_assertable_object(result)

    def find(self, **kwargs):
        if not isinstance(self.assertable_data, list):
            raise ValueError("Фильтрация доступна только для списков")

        result = []
        for key, value in kwargs.items():
            result = [item for item in self.assertable_data if item.get(key) == value]

        if len(result) > 1:
            raise ValueError('В резултате фильтрации найдено больше однного совпадения')

        return objects.make_assertable_object(result[0])

    def extract(self, query):
        if not isinstance(self.assertable_data, dict):
            raise ValueError("Извлечение доступна только для словарей")

        if not self.assertable_data.get(query):
            raise ValueError(f"ключ {query} не найден в словаре")

        return objects.make_assertable_object(self.assertable_data[query])
