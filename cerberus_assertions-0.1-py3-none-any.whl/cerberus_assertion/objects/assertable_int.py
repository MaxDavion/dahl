from cerberus_assertion.assertable_mixin import AssertableMixin


class AssertableInt(int, AssertableMixin):

    @property
    def document(self):
        return self

