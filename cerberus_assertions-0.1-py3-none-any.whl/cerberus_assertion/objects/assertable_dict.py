from cerberus_assertion.assertable_mixin import AssertableMixin

class AssertableDict(dict, AssertableMixin):

    @property
    def document(self):
        return self



