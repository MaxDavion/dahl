from cerberus_assertion.assertable_mixin import AssertableMixin


class AssertableList(list, AssertableMixin):

    @property
    def document(self):
        return self
