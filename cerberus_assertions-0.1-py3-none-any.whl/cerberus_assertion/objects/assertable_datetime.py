from cerberus_assertion.assertable_mixin import AssertableMixin


class AssertableDatetime(str, AssertableMixin):

    @property
    def document(self):
        return self
