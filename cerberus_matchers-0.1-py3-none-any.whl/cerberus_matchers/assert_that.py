from cerberus_matchers.assertable_list import AssertableList
from cerberus_matchers.assertable_dict import AssertableDict


def assert_that(arg):
    if isinstance(arg, dict):
        return AssertableDict(arg)
    elif isinstance(arg, list):
        return AssertableList(arg)
    raise ValueError('arg1 may be only list or dict')


def that(arg):
    return assert_that(arg)