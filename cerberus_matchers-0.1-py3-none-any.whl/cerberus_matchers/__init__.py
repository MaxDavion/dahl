from cerberus_matchers.assertable_dict import AssertableDict
from cerberus_matchers.assertable_list import AssertableList
from cerberus_matchers.matchers_lib import *

version = "0.1"
name = "cerberus_matchers"

def assert_that(arg):
    if isinstance(arg, dict):
        return AssertableDict(arg)
    elif isinstance(arg, list):
        return AssertableList
    raise ValueError('arg1 may be only list or dict')


def that(arg):
    return assert_that(arg)