from cerberus_matchers.cerberus_core import cerberus_assert_that
import hamcrest

__tracebackhide__ = True


class AssertableList(list):
    """ Обертка над `list`, добавляющая функциональность проверки его содержимого """

    def __init__(self, document):
        self._document = document
        super().__init__(document)

    def should(self, matcher):
        """ Проверить содержимое списка объектов
        :param matcher: функция-матчер, формата библиотеки hamcrest

        Использование:
            assert r.should(has_item(has_entries(quality="hd", price=250)))
            assert r.should(every_item(has_entries(price=greater_than(250))))
        """
        document = {"items": []}
        for i in self._document:
            document["items"].append(i)

        matcher = hamcrest.has_entries(items=matcher)
        return cerberus_assert_that(document, matcher)

    def filter(self, **kwargs):
        if not isinstance(self._document, list):
            raise TypeError('document is not list')

        for key, value in kwargs.items():
            pass

        self._document = [i for i in self._document if i[key] == value]
        return self.__class__(self._document)




