from cerberus_matchers.assertable_mixin import AssertableMixin
import hamcrest


class AssertableList(list, AssertableMixin):
    """ Обертка над `list`, добавляющая функциональность проверки его содержимого """

    def should(self, matcher):
        """ Проверить содержимое списка объектов
        :param matcher: функция-матчер, формата библиотеки hamcrest

        Использование:
            assert r.should(has_item(has_entries(quality="hd", price=250)))
            assert r.should(every_item(has_entries(price=greater_than(250))))
        """
        document = {"items": []}
        for i in self:
            if isinstance(i, dict):
                document["items"].append(i)
            else:
                document["items"].append(i.to_dict())
        matcher = hamcrest.has_entries(items=matcher)
        return self._assert_that(document, matcher)


