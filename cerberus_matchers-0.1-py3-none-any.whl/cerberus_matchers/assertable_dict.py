# -*- coding: utf-8 -*-
from cerberus_matchers.cerberus_core import cerberus_assert_that, jsonpath_get_one


__tracebackhide__ = True


class AssertableDict(dict):

    def __init__(self, document, offset=None):
        super().__init__()
        self._document = document
        self._offset: str = offset

    def __call__(self, query: str):
        if query.startswith('$'):
            document = jsonpath_get_one(self._document, query)
            return self.__class__(document)
        else:
            assert query in self._document, f"В теле ответа нет ключа `{query}`"
            return self.__class__(self._document, offset=query)

    # @property
    # def __document(self):
    #     return self.gson()[self._query] if self._query else self.gson()

    def should(self, matcher):
        if self._offset:
            return cerberus_assert_that(self._document, matcher, offset=self._offset)
        else:
            return cerberus_assert_that(self._document, matcher)









