# -*- coding: utf-8 -*-
from cerberus_matchers.assertable_mixin import AssertableMixin


class AssertableDict(dict, AssertableMixin):

    def __init__(self, document, offset=None):
        super().__init__()
        self._document = document
        self._offset = offset

    def __call__(self, offset):
        return self.extract(offset)

    # @property
    # def __document(self):
    #     return self.gson()[self._query] if self._query else self.gson()

    def extract(self, offset):
        assert offset in self._document, f"В теле ответа нет ключа `{offset}`"
        return self.__class__(self._document, offset=offset)

    def should(self, matcher):
        if self._offset:
            return self._assert_that(self._document, matcher, offset=self._offset)
        else:
            return self._assert_that(self._document, matcher)