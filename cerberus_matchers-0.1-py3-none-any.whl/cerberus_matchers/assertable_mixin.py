# -*- coding: utf-8 -*-
import hamcrest
from cerberus_matchers.matchers_lib.cerberus_matchers import extract as extract_as_cerberus_schema
from cerberus_matchers.cerberus_validators import SkyrimValidator

__tracebackhide__ = True


class AssertableMixin:

    def _assert_that(self, document, matcher, assertion_lib="cerberus", offset=None):
        if assertion_lib == "hamcrest":
            hamcrest.assert_that(document, matcher)
            return True
        elif assertion_lib == "cerberus":

            # Проверяем, что валидируемый документ - это либо словарь, либо список словарей
            if not isinstance(document, (list, dict)):
                raise TypeError('Валидируемый документ должен быть словарем (json) или '
                                'списком словарей.')

            # Если валидируемый документ - список, то делаем из него словарь, добавляя ключ `itmes`
            if isinstance(document, list):
                document = {"items": document}
                matcher = hamcrest.has_entries(items=matcher)

            # Базовая схема
            _base_schema = {}

            # Конвертируем hamcrest-матчеры в формат cerberus-схемы
            _matchers_schema = extract_as_cerberus_schema(matcher)

            if offset:
                _matchers_schema = {'schema': {offset: _matchers_schema}, 'type': 'dict'}

            # TODO: (Кузнецов М.) Написать тесты на то что схема дополняется, а не заменяется
            for k, v in _matchers_schema['schema'].items():
                if k not in _base_schema:
                    _base_schema.update({k: v})
                else:
                    _base_schema[k].update(v)

            return cerberus_check(_base_schema, document=document)
        else:
            raise ValueError("Некорректно задана библиотека валидации")


def cerberus_check(schema, document):
    """ Выполнить валидацию ответа по схеме
    Самый главный метод в этом процессе, именно тут происходит работа с Cerberus: валидация, вызов определенных
    в схеме правил валидации, формирование текста AssertionError
    (нее менять тут схему)
    :param schema:  схема валидации
    :param document: json ответ
    """
    v = SkyrimValidator(schema, allow_unknown=True, require_all=True)
    result = v.validate(document)

    if result is False:
        # Если в результате проверок нашлись ошибки, то выкидываем AssertionError c перечнем ошибок
        error_text = pretty_error_text(v.errors)
        raise AssertionError("".join(error_text))
    return True


def pretty_error_text(dict_with_errors):
    """ Сформировать и выдать легко-читаемое сообщение об ошибке """
    # TODO: (Кузнецов М) Тут нужен рефакторинг и описание
    fail_icon = '*'  # \N{Cross Mark}
    # fail_icon = '\N{Cross Mark}'
    error_texts_list = []

    def to_pretty(ddict, level=0):
        if isinstance(ddict, str):
            error_texts_list.append(f" \n{'    ' * level}{ddict}")

        elif isinstance(ddict, dict):
            for k, v in ddict.items():
                # otstup = '\t' * level
                otstup = '    ' * level

                if isinstance(v, str):
                    error_texts_list.append(f" \n{otstup}{fail_icon} {k}: {v}")
                elif isinstance(v, dict):
                    error_texts_list.append(f" \n{otstup}{fail_icon} {k}:")
                    to_pretty(v, level=level+1)
                elif isinstance(v, list):
                    assert len(v) < 3
                    if len(v) == 1:
                        to_pretty({k:v[0]}, level=level)
                    else:
                        error_texts_list.append(f" \n{otstup}{fail_icon} {k}: {v[0]}")
                        to_pretty(v[1], level=level+1)
                else:
                    raise TypeError("Не удалось распарсить результат работы cerberus")

        else:
            raise TypeError("Не удалось распарсить список ошибок")

    to_pretty(dict_with_errors)
    return error_texts_list









