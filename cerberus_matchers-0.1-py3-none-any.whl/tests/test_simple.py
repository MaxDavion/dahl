from cerberus_matchers import that, AssertableDict, has_entries, equal_to, has_item


def test_dict():
    assert that({"name": "Вася",  "age": 22}).should(has_entries(age=22))


def test_list():
    assert that(["Вася", "Петя"]).should(has_item("Вася"))


def test_one():
    document = AssertableDict({"name": "Вася", "age": 22})
    assert document.should(has_entries(age=22))


def test_two():
    document = AssertableDict({"name": "Вася", "age": 22})
    assert document('name').should(equal_to("Вася"))
    assert document('age').should(equal_to(22))


def test_three():
    document = AssertableDict({"name": {"one": "Вася", "two": "Коля"}, "age": 22})

    assert document.extract("name").should(has_entries(one="Вася"))
    assert document('name').should(has_entries(one="Вася"))