import pytest
from cerberus_matchers import *
from cerberus_matchers.assertable_list import AssertableList
from tests.utils import parse_exeption


"""
$.prime[?(id=36)]



"""

def test_uyituryter():
    users = AssertableDict({"age": {"id": 1, "name": "Qwerty"}, "prime": [
        {'user': 'Fred', 'id': 36, 'active': True},
        {'user': 'Bob', 'id': 40, 'active': False},
        {'user': 'Johnny', 'id': 13, 'active': True}
    ]})

    users("age").should(has_entries(
        id=1,
        name="Qwerty"
    ))

    users("$.age").should(has_entries(
        id=1,
        name="Qwerty"
    ))

    users("$.prime[?(id=36)]").should(
        has_entries(
            user='Fred',
            active=True
        ))