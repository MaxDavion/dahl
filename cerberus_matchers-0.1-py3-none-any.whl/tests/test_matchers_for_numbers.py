from cerberus_matchers import *
import pytest
from tests.utils import parse_exeption


""" Тесты на работу number-валидаторов в схеме Cerberus с разными наборами данных """

@pytest.mark.parametrize("matcher", [
    close_to(123450, 6),
    greater_than(123455),
    greater_than_or_equal_to(123456),
    less_than(123457),
    less_than_or_equal_to(123456),
])
def test_number_matchers(doc_json, matcher):
    " Тесты на матчер позитивные """
    assert doc_json('id').should(matcher)
    assert doc_json.should(has_entries(id=matcher))
    assert doc_json.should(has_entries({"id": matcher}))


def test_deny_using_negatives_with_comparison_matchers(doc_json):
    """ Запрет использования отрицания с матчерами сравнения """
    with pytest.raises(TypeError) as excinfo:
        assert doc_json.should(has_entries(id=not_(greater_than(123455))))
    assert "Вместо матчера с отрицанием `not_(greater_than(123455))`, лучше использовать его антипод" \
           in str(excinfo.value)


@pytest.mark.parametrize("matcher, error_text", [
    (close_to(123450, 5), "id: Must be close to <123450> with delta <5>, but was <123456> differed by <6>"),
    (greater_than(200000), "id: Must be greater than <200000> but was <123456>"),
    (greater_than_or_equal_to(200000), "id: Must be greater than or equal to <200000> but was <123456>"),
    (less_than(100000), "id: Must be less than <100000> but was <123456>"),
    (less_than_or_equal_to(100000), "id: Must be less than or equal to <100000> but was <123456>"),
])
def test_number_matchers_with_raises(doc_json, matcher, error_text):
    """ Тесты на выдачу ошибки матчером """
    with pytest.raises(AssertionError) as excinfo:
        assert doc_json('id').should(matcher)
    exeptions = parse_exeption(excinfo)
    assert len(exeptions) == 1
    assert error_text in exeptions[0]

    with pytest.raises(AssertionError) as excinfo:
        assert doc_json.should(has_entries(id=matcher))
    exeptions = parse_exeption(excinfo)
    assert len(exeptions) == 1
    assert error_text in exeptions[0]

    with pytest.raises(AssertionError) as excinfo:
        assert doc_json.should(has_entries({"id": matcher}))
    exeptions = parse_exeption(excinfo)
    assert len(exeptions) == 1
    assert error_text in exeptions[0]


