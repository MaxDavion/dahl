import pytest
from cerberus_matchers import *
from tests.utils import parse_exeption


""" Тесты на работу валидатора типа данных в схеме Cerberus с разными наборами данных """


@pytest.mark.parametrize("matcher", [
    has_entries(
        id=instance_of(int),
        name=instance_of(str),
        is_purchased=instance_of(bool),
        devices=instance_of(list),
        raitings=instance_of(dict),
    ),
    has_entries(
        id=is_(int),
        name=is_(str),
        is_purchased=is_(bool),
        devices=is_(list),
        raitings=is_(dict)
    )
])
def test_instance_of_matcher(doc_json, matcher):
    " Тесты на матчер позитивные """
    assert doc_json.should(matcher)


@pytest.mark.parametrize("matcher", [
    has_entries(
        id=instance_of(str),
        name=instance_of(bool),
        is_purchased=instance_of(int),
        devices=instance_of(dict),
        raitings=instance_of(list),
    ),
    has_entries(
        id=is_(str),
        name=is_(bool),
        is_purchased=is_(bool),
        devices=is_(dict),
        raitings=is_(list)
    )
])
def test_instance_of_matcher_with_raises(doc_json, matcher):
    " Тесты на выдачу ошибки матчером (позитивные сценарии) """
    with pytest.raises(AssertionError) as excinfo:
        assert doc_json.should(matcher)
    exeptions = parse_exeption(excinfo)
    assert len(exeptions) == 4
    assert "devices: must be of dict type" in exeptions[0]
    assert "id: must be of string type" in exeptions[1]
    assert "name: must be of boolean type" in exeptions[2]
    assert "raitings: must be of list type" in exeptions[3]



