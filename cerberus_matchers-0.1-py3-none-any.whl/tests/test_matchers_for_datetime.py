import pytest
from cerberus_matchers import *
from tests.utils import parse_exeption


@pytest.mark.skip
class TestIsToday:
    """ Тесты на матчеры is_today, is_tomorrow, is_yesterday, is_today_with_shift """

    # ------------------------- Позитивные тесты -------------------------------
    def test_is_today_positive(self, doc_json):
        """ Позитивный тест на матчер is_today """
        assert doc_json("datetimes").should(has_entries(today=is_today()))

    def test_is_tomorrow_positive(self, doc_json):
        """ Позитивный тест на матчер is_tomorrow """
        assert doc_json("datetimes").should(has_entries(tomorrow=is_tomorrow()))

    def test_is_yesterday_positive(self, doc_json):
        """ Позитивный тест на матчер is_yesterday """
        assert doc_json("datetimes").should(has_entries(yesterday=is_yesterday()))

    @pytest.mark.parametrize("matcher", [
        has_entries(today=is_today_with_shift()),
        has_entries(tomorrow=is_today_with_shift(days=1)),
        has_entries(tomorrow=is_today_with_shift(hours=24)),
        has_entries(yesterday=is_today_with_shift(days=-1)),
        has_entries(yesterday=is_today_with_shift(hours=-24)),
        has_entries(custom_date=is_today_with_shift(weeks=1, days=2, hours=48))
    ])
    def test_is_today_with_shift_positive(self, doc_json, matcher):
        """ Позитивные тесты на матчер is_today_with_shift """
        assert doc_json("datetimes").should(matcher)

    # ------------------------- Негативные тесты -------------------------------
    @pytest.mark.parametrize("matcher, error_msg", [
        (has_entries(tomorrow=is_today()),
         lambda r: f"    * tomorrow: Expected: today, but was: <{r['datetimes']['tomorrow']}>"),
        (has_entries(yesterday=is_today()),
         lambda r: f"    * yesterday: Expected: today, but was: <{r['datetimes']['yesterday']}>"),
        (has_entries(custom_date=is_today()),
         lambda r: f"    * custom_date: Expected: today, but was: <{r['datetimes']['custom_date']}>")
    ])
    def test_is_today_negative(self, doc_json, matcher, error_msg):
        """ Негативные тесты на матчер is_today """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json("datetimes").should(matcher)
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 2
        assert exeptions[0] == "* datetimes: "
        assert exeptions[1] == error_msg(doc_json)

    @pytest.mark.parametrize("matcher, error_msg", [
        (has_entries(today=is_tomorrow()),
         lambda r: f"    * today: Expected: tomorrow, but was: <{r['datetimes']['today']}>"),
        (has_entries(yesterday=is_tomorrow()),
         lambda r: f"    * yesterday: Expected: tomorrow, but was: <{r['datetimes']['yesterday']}>"),
        (has_entries(custom_date=is_tomorrow()),
         lambda r: f"    * custom_date: Expected: tomorrow, but was: <{r['datetimes']['custom_date']}>")
    ])
    def test_is_tomorrow_negative(self, doc_json, matcher, error_msg):
        """ Негативные тесты на матчер is_tomorrow """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json("datetimes").should(matcher)
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 2
        assert exeptions[0] == "* datetimes: "
        assert exeptions[1] == error_msg(doc_json)

    @pytest.mark.parametrize("matcher, error_msg", [
        (has_entries(today=is_yesterday()),
         lambda r: f"    * today: Expected: yesterday, but was: <{r['datetimes']['today']}>"),
        (has_entries(tomorrow=is_yesterday()),
         lambda r: f"    * tomorrow: Expected: yesterday, but was: <{r['datetimes']['tomorrow']}>"),
        (has_entries(custom_date=is_yesterday()),
         lambda r: f"    * custom_date: Expected: yesterday, but was: <{r['datetimes']['custom_date']}>")
    ])
    def test_is_yesterday_negative(self, doc_json, matcher, error_msg):
        """ Негативные тесты на матчер is_yesterday """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json("datetimes").should(matcher)
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 2
        assert exeptions[0] == "* datetimes: "
        assert exeptions[1] == error_msg(doc_json)

    @pytest.mark.parametrize("matcher, error_msg", [
        (has_entries(today=is_today_with_shift(days=1)),
         lambda r: f"    * today: Expected: tomorrow, but was: <{r['datetimes']['today']}>"),
        (has_entries(today=is_today_with_shift(hours=24)),
         lambda r: f"    * today: Expected: tomorrow, but was: <{r['datetimes']['today']}>"),
        (has_entries(today=is_today_with_shift(days=-1)),
         lambda r: f"    * today: Expected: yesterday, but was: <{r['datetimes']['today']}>"),
        (has_entries(today=is_today_with_shift(hours=-24)),
         lambda r: f"    * today: Expected: yesterday, but was: <{r['datetimes']['today']}>"),
        (has_entries(today=is_today_with_shift(weeks=1)),
         lambda r: f"    * today: Expected: today with time shift of 1 weeks, but was: <{r['datetimes']['today']}>"),
        (has_entries(today=is_today_with_shift(days=-5)),
         lambda r: f"    * today: Expected: today with time shift of -5 days, but was: <{r['datetimes']['today']}>"),
        (has_entries(today=is_today_with_shift(hours=48)),
         lambda r: f"    * today: Expected: today with time shift of 48 hours, but was: <{r['datetimes']['today']}>"),
        (has_entries(tomorrow=is_today_with_shift()),
         lambda r: f"    * tomorrow: Expected: today, but was: <{r['datetimes']['tomorrow']}>"),
        (has_entries(custom_date=is_today_with_shift(weeks=3, days=5, hours=56)),
         lambda r: f"    * custom_date: Expected: today with time shift of 56 hours and 5 days and 3 weeks, but was: <{r['datetimes']['custom_date']}>")
    ])
    def test_is_today_with_shift_negative(self, doc_json, matcher, error_msg):
        """ Негативные тесты на матчер is_today_with_shift """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json("datetimes").should(matcher)
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 2
        assert exeptions[0] == "* datetimes: "
        assert exeptions[1] == error_msg(doc_json)

    # ------------------------- Позитивные тесты на отрицание (not_) -------------------------------
    @pytest.mark.parametrize("matcher", [
        has_entries(tomorrow=not_(is_today())),
        has_entries(yesterday=not_(is_today())),
        has_entries(custom_date=not_(is_today()))
    ])
    def test_not_is_today_positive(self, r, matcher):
        """ Позитивные тесты на отрицание матчера is_today """
        assert r("datetimes").should(matcher)

    @pytest.mark.parametrize("matcher", [
        has_entries(today=not_(is_tomorrow())),
        has_entries(yesterday=not_(is_tomorrow())),
        has_entries(custom_date=not_(is_tomorrow()))
    ])
    def test_not_is_tomorrow_positive(self, doc_json, matcher):
        """ Позитивные тесты на отрицание матчера is_tomorrow """
        assert doc_json("datetimes").should(matcher)

    @pytest.mark.parametrize("matcher", [
        has_entries(tomorrow=not_(is_yesterday())),
        has_entries(today=not_(is_yesterday())),
        has_entries(custom_date=not_(is_yesterday()))
    ])
    def test_not_is_yesterday_positive(self, r, matcher):
        """ Позитивные тесты на отрицание матчера is_yesterday """
        assert r("datetimes").should(matcher)

    @pytest.mark.parametrize("matcher", [
        has_entries(today=not_(is_today_with_shift(days=-10))),
        has_entries(custom_date=not_(is_today_with_shift(weeks=-10, days=1, hours=55))),
    ])
    def test_not_is_today_with_shift_positive(self, doc_json, matcher):
        """ Позитивные тесты на отрицание матчера is_today_with_shift """
        assert doc_json("datetimes").should(matcher)

    # ------------------------- Негативные тесты на отрицание (not_) -------------------------------
    def test_not_is_today_negative(self, doc_json):
        """ Негативные тесты на отрицание матчера is_today """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json("datetimes").should(has_entries(today=not_(is_today())))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 2
        assert exeptions[0] == "* datetimes: "
        assert exeptions[1] == f"    * today: Expected: not today, but was: <{doc_json.json()['datetimes']['today']}>"

    def test_not_is_tomorrow_negative(self, doc_json):
        """ Негативные тесты на отрицание матчера is_tomorrow """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json("datetimes").should(has_entries(tomorrow=not_(is_tomorrow())))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 2
        assert exeptions[0] == "* datetimes: "
        assert exeptions[1] == f"    * tomorrow: Expected: not tomorrow, but was: <{doc_json.json()['datetimes']['tomorrow']}>"

    def test_not_is_yesterday_negative(self, doc_json):
        """ Негативные тесты на отрицание матчера is_yesterday """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json("datetimes").should(has_entries(yesterday=not_(is_yesterday())))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 2
        assert exeptions[0] == "* datetimes: "
        assert exeptions[1] == f"    * yesterday: Expected: not yesterday, but was: <{doc_json.json()['datetimes']['yesterday']}>"

    @pytest.mark.parametrize("matcher, error_msg", [
        (has_entries(today=not_(is_today_with_shift())),
         lambda r: f"    * today: Expected: not today, but was: <{r['datetimes']['today']}>"),
        (has_entries(tomorrow=not_(is_today_with_shift(hours=24))),
         lambda r: f"    * tomorrow: Expected: not tomorrow, but was: <{r['datetimes']['tomorrow']}>"),
        (has_entries(tomorrow=not_(is_today_with_shift(days=1))),
         lambda r: f"    * tomorrow: Expected: not tomorrow, but was: <{r['datetimes']['tomorrow']}>"),
        (has_entries(yesterday=not_(is_today_with_shift(hours=-24))),
         lambda r: f"    * yesterday: Expected: not yesterday, but was: <{r['datetimes']['yesterday']}>"),
        (has_entries(yesterday=not_(is_today_with_shift(days=-1))),
         lambda r: f"    * yesterday: Expected: not yesterday, but was: <{r['datetimes']['yesterday']}>"),
        (has_entries(custom_date=not_(is_today_with_shift(weeks=1, days=2, hours=48))),
         lambda r: f"    * custom_date: Expected: not today with time shift of 48 hours and 2 days and 1 weeks, but was: <{r['datetimes']['custom_date']}>"),
    ])
    def test_not_is_today_with_shift_negative(self, doc_json, matcher, error_msg):
        """ Негативные тесты на отрицание матчера is_today_with_shift """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json("datetimes").should(matcher)
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 2
        assert exeptions[0] == "* datetimes: "
        assert exeptions[1] == error_msg(doc_json)


@pytest.mark.skip
class TestDateComparison:
    """ Тесты на матчеры сравнения дат: is_greater_than_datetime, is_less_than_datetime, is_equal_to_datetime,
        is_greater_than_date, is_less_than_date, is_equal_to_date, is_equal_to_date_ignoring_seconds
    """

    @pytest.mark.parametrize("matcher", [
        lambda r: is_greater_than_datetime(r["datetimes"]["today_minus_7_seconds"]),
        lambda r: is_greater_than_datetime(r["datetimes"]["yesterday"]),
    ])
    def test_is_greater_than_datetime_positive(self, doc_json, matcher):
        """ Позитивный тест на матчер is_greater_than_datetime """
        assert doc_json("datetimes").should(has_entries(today=matcher(doc_json)))

    @pytest.mark.parametrize("matcher", [
        lambda r: is_less_than_datetime(r["datetimes"]["today_plus_5_seconds"]),
        lambda r: is_less_than_datetime(r["datetimes"]["tomorrow"]),
    ])
    def test_is_less_than_datetime_positive(self, doc_json, matcher):
        """ Позитивный тест на матчер is_less_than_datetime """
        assert doc_json("datetimes").should(has_entries(today=matcher(doc_json)))

    def test_is_equal_to_datetime_positive(self, doc_json):
        """ Позитивный тест на матчер is_equal_to_datetime """
        assert doc_json("datetimes").should(has_entries(today=is_equal_to_datetime(doc_json["datetimes"]["today"])))

    def test_is_greater_than_date_positive(self, doc_json):
        """ Позитивный тест на матчер is_greater_than_date """
        assert doc_json("datetimes").should(has_entries(today=is_greater_than_date(doc_json["datetimes"]["yesterday"])))

    def test_is_less_than_date_positive(self, doc_json):
        """ Позитивный тест на матчер is_less_than_date """
        assert doc_json("datetimes").should(has_entries(today=is_less_than_date(doc_json["datetimes"]["tomorrow"])))

    @pytest.mark.parametrize("matcher", [
        lambda r: is_equal_to_date(r()["datetimes"]["today"]),
        lambda r: is_equal_to_date(r()["datetimes"]["today_plus_5_seconds"]),
        lambda r: is_equal_to_date(r()["datetimes"]["today_minus_7_seconds"])
    ])
    def test_is_equal_to_date_positive(self, doc_json, matcher):
        """ Позитивный тест на матчер is_equal_to_date """
        assert doc_json("datetimes").should(has_entries(today=matcher(doc_json)))

    @pytest.mark.parametrize("matcher", [
        lambda r: is_equal_to_date_ignoring_seconds(r["datetimes"]["today"]),
        lambda r: is_equal_to_date_ignoring_seconds(r["datetimes"]["today_plus_5_seconds"]),
        lambda r: is_equal_to_date_ignoring_seconds(r["datetimes"]["today_minus_7_seconds"], seconds=7),
    ])
    def test_is_equal_to_date_ignoring_seconds_positive(self, doc_json, matcher):
        """ Позитивный тест на матчер is_equal_to_date_ignoring_seconds """
        assert doc_json("datetimes").should(has_entries(today=matcher(doc_json)))

    # ------------------------- Негативные тесты -------------------------------
    @pytest.mark.parametrize("matcher, error_msg", [
        (lambda r: is_greater_than_datetime(r()["datetimes"]["today"]),
         lambda r: f"    * today: Must be greater than <{r['datetimes']['today']}>, "
                   f"but was: <{r['datetimes']['today']}> is not greater"),
        (lambda r: is_greater_than_datetime(r["datetimes"]["today_plus_5_seconds"]),
         lambda r: f"    * today: Must be greater than <{r['datetimes']['today_plus_5_seconds']}>, "
                   f"but was: <{r['datetimes']['today']}> is not greater"),
    ])
    def test_is_greater_than_datetime_negative(self, doc_json, matcher, error_msg):
        """ Негативный тест на матчер is_greater_than_datetime """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json("datetimes").should(has_entries(today=matcher(doc_json)))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 2
        assert exeptions[0] == "* datetimes: "
        assert exeptions[1] == error_msg(doc_json)

    @pytest.mark.parametrize("matcher, error_msg", [
        (lambda r: is_less_than_datetime(r["datetimes"]["today"]),
         lambda r: f"    * today: Must be less than <{r['datetimes']['today']}>, "
                   f"but was: <{r['datetimes']['today']}> is not less"),
        (lambda r: is_less_than_datetime(r["datetimes"]["today_minus_7_seconds"]),
         lambda r: f"    * today: Must be less than <{r['datetimes']['today_minus_7_seconds']}>, "
                   f"but was: <{r['datetimes']['today']}> is not less"),
    ])
    def test_is_less_than_datetime_negative(self, doc_json, matcher, error_msg):
        """ Негативный тест на матчер is_less_than_datetime """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json("datetimes").should(has_entries(today=matcher(doc_json)))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 2
        assert exeptions[0] == "* datetimes: "
        assert exeptions[1] == error_msg(doc_json)

    @pytest.mark.parametrize("matcher, error_msg", [
        (lambda r: is_equal_to_datetime(r["datetimes"]["today_plus_5_seconds"]),
         lambda r: f"    * today: Must be equal to <{r['datetimes']['today_plus_5_seconds']}>, "
                   f"but was: <{r['datetimes']['today']}>"),
        (lambda r: is_equal_to_datetime(r["datetimes"]["today_minus_7_seconds"]),
         lambda r: f"    * today: Must be equal to <{r['datetimes']['today_minus_7_seconds']}>, "
                   f"but was: <{r['datetimes']['today']}>"),
    ])
    def test_is_equal_to_datetime_negative(self, doc_json, matcher, error_msg):
        """ Негативный тест на матчер is_equal_to_datetime """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json("datetimes").should(has_entries(today=matcher(doc_json)))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 2
        assert exeptions[0] == "* datetimes: "
        assert exeptions[1] == error_msg(doc_json)

    @pytest.mark.parametrize("matcher, error_msg", [
        (lambda r: is_greater_than_date(r["datetimes"]["today"]),
         lambda r: f"    * today: Must be greater than <{r['datetimes']['today']}>, "
                   f"but was: <{r['datetimes']['today']}> is not greater (ignoring time)"),
        (lambda r: is_greater_than_date(r["datetimes"]["today_minus_7_seconds"]),
         lambda r: f"    * today: Must be greater than <{r['datetimes']['today_minus_7_seconds']}>, "
                   f"but was: <{r['datetimes']['today']}> is not greater (ignoring time)"),
        (lambda r: is_greater_than_date(r["datetimes"]["today_plus_5_seconds"]),
         lambda r: f"    * today: Must be greater than <{r['datetimes']['today_plus_5_seconds']}>, "
                   f"but was: <{r['datetimes']['today']}> is not greater (ignoring time)")
    ])
    def test_is_greater_than_date_negative(self, doc_json, matcher, error_msg):
        """ Негативный тест на матчер is_greater_than_date """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json("datetimes").should(has_entries(today=matcher(doc_json)))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 2
        assert exeptions[0] == "* datetimes: "
        assert exeptions[1] == error_msg(doc_json)

    @pytest.mark.parametrize("matcher, error_msg", [
        (lambda r: is_less_than_date(r["datetimes"]["today"]),
         lambda r: f"    * today: Must be less than <{r['datetimes']['today']}>, "
                   f"but was: <{r['datetimes']['today']}> is not less (ignoring time)"),
        (lambda r: is_less_than_date(r["datetimes"]["today_minus_7_seconds"]),
         lambda r: f"    * today: Must be less than <{r['datetimes']['today_minus_7_seconds']}>, "
                   f"but was: <{r['datetimes']['today']}> is not less (ignoring time)"),
        (lambda r: is_less_than_date(r["datetimes"]["today_plus_5_seconds"]),
         lambda r: f"    * today: Must be less than <{r['datetimes']['today_plus_5_seconds']}>, "
                   f"but was: <{r['datetimes']['today']}> is not less (ignoring time)")
    ])
    def test_is_less_than_date_negative(self, doc_json, matcher, error_msg):
        """ Негативный тест на матчер is_less_than_date """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json("datetimes").should(has_entries(today=matcher(doc_json)))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 2
        assert exeptions[0] == "* datetimes: "
        assert exeptions[1] == error_msg(doc_json)

    @pytest.mark.parametrize("matcher, error_msg", [
        (lambda r: is_equal_to_date(r["datetimes"]["yesterday"]),
         lambda r: f"    * today: Must be equal to <{r['datetimes']['yesterday']}>, "
                   f"but was: <{r['datetimes']['today']}> (ignoring time)"),
        (lambda r: is_equal_to_date(r["datetimes"]["tomorrow"]),
         lambda r: f"    * today: Must be equal to <{r['datetimes']['tomorrow']}>, "
                   f"but was: <{r['datetimes']['today']}> (ignoring time)"),
    ])
    def test_is_equal_to_date_negative(self, doc_json, matcher, error_msg):
        """ Негативный тест на матчер is_equal_to_date """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json("datetimes").should(has_entries(today=matcher(doc_json)))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 2
        assert exeptions[0] == "* datetimes: "
        assert exeptions[1] == error_msg(doc_json)

    @pytest.mark.parametrize("matcher, error_msg", [
        (lambda r: is_equal_to_date_ignoring_seconds(r["datetimes"]["today_minus_7_seconds"]),
         lambda r: f"    * today: Must be equal to <{r['datetimes']['today_minus_7_seconds']}>, "
                   f"but was: <{r['datetimes']['today']}> (ignoring 5 seconds)"),
        (lambda r: is_equal_to_date_ignoring_seconds(r["datetimes"]["today_plus_5_seconds"], seconds=3),
         lambda r: f"    * today: Must be equal to <{r['datetimes']['today_plus_5_seconds']}>, "
                   f"but was: <{r['datetimes']['today']}> (ignoring 3 seconds)"),
    ])
    def test_is_equal_to_date_ignoring_seconds_negative(self, doc_json, matcher, error_msg):
        """ Негативный тест на матчер is_equal_to_date_ignoring_seconds """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json("datetimes").should(has_entries(today=matcher(doc_json)))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 2
        assert exeptions[0] == "* datetimes: "
        assert exeptions[1] == error_msg(doc_json)

    # ------------------------- Позитивные тесты на отрицание (not_) -------------------------------
    def test_not_is_greater_than_datetime_positive(self, doc_json):
        """ Позитивный тест на отрицание матчера is_greater_than_datetime """
        assert doc_json("datetimes").should(has_entries(
            today=not_(is_greater_than_datetime(doc_json["datetimes"]["tomorrow"]))))

    def test_not_is_less_than_datetime_positive(self, doc_json):
        """ Позитивный тест на отрицание матчера is_less_than_datetime """
        assert doc_json("datetimes").should(has_entries(
            today=not_(is_less_than_datetime(doc_json["datetimes"]["yesterday"]))))

    def test_not_is_equal_to_datetime_positive(self, doc_json):
        """ Позитивный тест на отрицание матчера is_equal_to_datetime """
        assert doc_json("datetimes").should(has_entries(
            today=not_(is_equal_to_datetime(doc_json["datetimes"]["tomorrow"]))))

    @pytest.mark.parametrize("matcher", [
        lambda r: not_(is_greater_than_date(r["datetimes"]["tomorrow"])),
        lambda r: not_(is_greater_than_date(r["datetimes"]["today"]))
    ])
    def test_not_is_greater_than_date_positive(self, doc_json, matcher):
        """ Позитивный тест на отрицание матчера is_greater_than_date """
        assert doc_json("datetimes").should(has_entries(today=matcher(doc_json)))

    @pytest.mark.parametrize("matcher", [
        lambda r: not_(is_less_than_date(r["datetimes"]["yesterday"])),
        lambda r: not_(is_less_than_date(r["datetimes"]["today"]))
    ])
    def test_not_is_less_than_date_positive(self, doc_json, matcher):
        """ Позитивный тест на отрицание матчера is_less_than_date """
        assert doc_json("datetimes").should(has_entries(
            today=matcher(doc_json)))

    @pytest.mark.parametrize("matcher", [
        lambda r: not_(is_equal_to_date(r["datetimes"]["yesterday"])),
        lambda r: not_(is_equal_to_date(r["datetimes"]["tomorrow"]))
    ])
    def test_not_is_equal_to_date_positive(self, doc_json, matcher):
        """ Позитивный тест на отрицание матчера is_equal_to_date """
        assert doc_json("datetimes").should(has_entries(
            today=matcher(doc_json)))

    @pytest.mark.parametrize("matcher", [
        lambda r: not_(is_equal_to_date_ignoring_seconds(r["datetimes"]["today_plus_5_seconds"], seconds=4)),
        lambda r: not_(is_equal_to_date_ignoring_seconds(r["datetimes"]["today_minus_7_seconds"])),
    ])
    def test_not_is_equal_to_date_ignoring_seconds_positive(self, doc_json, matcher):
        """ Позитивный тест на отрицание матчера is_equal_to_date_ignoring_seconds """
        assert doc_json("datetimes").should(has_entries(today=matcher(doc_json)))

    # ------------------------- Негативные тесты на отрицание (not_) -------------------------------

    @pytest.mark.parametrize("matcher, error_msg", [
        (lambda r: not_(is_greater_than_datetime(r["datetimes"]["yesterday"])),
         lambda r: f"    * today: Must not be greater than <{r['datetimes']['yesterday']}>, "
                   f"but was: <{r['datetimes']['today']}> is greater"),
        (lambda r: not_(is_greater_than_datetime(r["datetimes"]["today_minus_7_seconds"])),
         lambda r: f"    * today: Must not be greater than <{r['datetimes']['today_minus_7_seconds']}>, "
                   f"but was: <{r['datetimes']['today']}> is greater")
    ])
    def test_not_is_greater_than_datetime_negative(self, doc_json, matcher, error_msg):
        """ Негативный тест на отрицание матчера is_greater_than_datetime """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json("datetimes").should(has_entries(today=matcher(doc_json)))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 2
        assert exeptions[0] == "* datetimes: "
        assert exeptions[1] == error_msg(doc_json)

    @pytest.mark.parametrize("matcher, error_msg", [
        (lambda r: not_(is_less_than_datetime(r["datetimes"]["tomorrow"])),
         lambda r: f"    * today: Must not be less than <{r['datetimes']['tomorrow']}>, "
                   f"but was: <{r['datetimes']['today']}> is less"),
        (lambda r: not_(is_less_than_datetime(r["datetimes"]["today_plus_5_seconds"])),
         lambda r: f"    * today: Must not be less than <{r['datetimes']['today_plus_5_seconds']}>, "
                   f"but was: <{r['datetimes']['today']}> is less")
    ])
    def test_not_is_less_than_datetime_negative(self, doc_json, matcher, error_msg):
        """ Негативный тест на отрицание матчера is_less_than_datetime """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json("datetimes").should(has_entries(today=matcher(doc_json)))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 2
        assert exeptions[0] == "* datetimes: "
        assert exeptions[1] == error_msg(doc_json)

    @pytest.mark.parametrize("matcher, error_msg", [
        (lambda r: not_(is_equal_to_datetime(r["datetimes"]["today"])),
         lambda r: f"    * today: Must not be equal to <{r['datetimes']['today']}>, "
                   f"but was: <{r['datetimes']['today']}>")
    ])
    def test_not_is_equal_to_datetime_negative(self, doc_json, matcher, error_msg):
        """ Негативный тест на отрицание матчера is_equal_to_datetime """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json("datetimes").should(has_entries(today=matcher(doc_json)))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 2
        assert exeptions[0] == "* datetimes: "
        assert exeptions[1] == error_msg(doc_json)

    @pytest.mark.parametrize("matcher, error_msg", [
        (lambda r: not_(is_greater_than_date(r["datetimes"]["yesterday"])),
         lambda r: f"    * today: Must not be greater than <{r['datetimes']['yesterday']}>, "
                   f"but was: <{r['datetimes']['today']}> is greater (ignoring time)")
    ])
    def test_not_is_greater_than_date_negative(self, doc_json, matcher, error_msg):
        """ Негативный тест на отрицание матчера is_greater_than_date """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json("datetimes").should(has_entries(today=matcher(doc_json)))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 2
        assert exeptions[0] == "* datetimes: "
        assert exeptions[1] == error_msg(doc_json)

    @pytest.mark.parametrize("matcher, error_msg", [
        (lambda r: not_(is_less_than_date(r["datetimes"]["tomorrow"])),
         lambda r: f"    * today: Must not be less than <{r['datetimes']['tomorrow']}>, "
                   f"but was: <{r['datetimes']['today']}> is less (ignoring time)")
    ])
    def test_not_is_less_than_date_negative(self, doc_json, matcher, error_msg):
        """ Негативный тест на отрицание матчера is_less_than_date """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json("datetimes").should(has_entries(today=matcher(doc_json)))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 2
        assert exeptions[0] == "* datetimes: "
        assert exeptions[1] == error_msg(doc_json)

    @pytest.mark.parametrize("matcher, error_msg", [
        (lambda r: not_(is_equal_to_date(r["datetimes"]["today"])),
         lambda r: f"    * today: Must not be equal to <{r['datetimes']['today']}>, "
                   f"but was: <{r['datetimes']['today']}> (ignoring time)"),
        (lambda r: not_(is_equal_to_date(r["datetimes"]["today_plus_5_seconds"])),
         lambda r: f"    * today: Must not be equal to <{r['datetimes']['today_plus_5_seconds']}>, "
                   f"but was: <{r['datetimes']['today']}> (ignoring time)"),
        (lambda r: not_(is_equal_to_date(r["datetimes"]["today_minus_7_seconds"])),
         lambda r: f"    * today: Must not be equal to <{r['datetimes']['today_minus_7_seconds']}>, "
                   f"but was: <{r['datetimes']['today']}> (ignoring time)")
    ])
    def test_not_is_equal_to_date_negative(self, doc_json, matcher, error_msg):
        """ Негативный тест на отрицание матчера is_equal_to_date """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json("datetimes").should(has_entries(today=matcher(doc_json)))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 2
        assert exeptions[0] == "* datetimes: "
        assert exeptions[1] == error_msg(doc_json)

    @pytest.mark.parametrize("matcher, error_msg", [
        (lambda r: not_(is_equal_to_date_ignoring_seconds(r["datetimes"]["today_plus_5_seconds"])),
         lambda r: f"    * today: Must not be equal to <{r['datetimes']['today_plus_5_seconds']}>, "
                   f"but was: <{r['datetimes']['today']}> (ignoring 5 seconds)"),
        (lambda r: not_(is_equal_to_date_ignoring_seconds(r["datetimes"]["today_minus_7_seconds"], seconds=8)),
         lambda r: f"    * today: Must not be equal to <{r['datetimes']['today_minus_7_seconds']}>, "
                   f"but was: <{r['datetimes']['today']}> (ignoring 8 seconds)"),
    ])
    def test_not_is_equal_to_date_ignoring_seconds_negative(self, doc_json, matcher, error_msg):
        """ Негативный тест на отрицание матчера is_equal_to_date_ignoring_seconds """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json("datetimes").should(has_entries(today=matcher(doc_json)))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 2
        assert exeptions[0] == "* datetimes: "
        assert exeptions[1] == error_msg(doc_json)
