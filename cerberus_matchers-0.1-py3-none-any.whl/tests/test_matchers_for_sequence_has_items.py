from cerberus_matchers import *
import pytest
from tests.utils import parse_exeption

""" Тесты на работу валидатора has_item (любой элемент последовательности) в схеме Cerberus с разными наборами данных 
"""

class TestSequenceHasItemsMatcherForSimpleData:
    """ Тесты на работу валидатора `has_items` с простыми типами данных """

    @pytest.mark.parametrize("matcher", [
        has_item("Apple Device"),
        has_item(starts_with("Android")),
        # not_(has_item("Web Device"))
        has_item_at_index(1, "Apple Device"),
        has_item_at_index(-1, "Stb Device"),
        has_first_item("Android Device"),
        has_last_item("Stb Device"),
        has_item_at_index(-2, starts_with("Apple")),
        has_first_item(contains_string("Android"))
    ])
    def test_list_has_item_matcher_for_simple_data(self, doc_json, matcher):
        """
        Тесты на матчер `has_item` и `has_item_at_index`, позитивные и с отрицанием
        (список содержит простые типы данных).
        """
        assert doc_json('devices').should(matcher)
        assert doc_json.should(has_entries(devices=matcher))
        assert doc_json.should(has_entries({"devices": matcher}))

    errors_list_1 = [
        "devices: any item",
        "0: Must be `Web Device`, but was `Android Device`",
        "1: Must be `Web Device`, but was `Apple Device`",
        "2: Must be `Web Device`, but was `Stb Device`"
    ]

    errors_list_2 = [
            "devices: any item",
            "0: Must be a string starts with 'Smart', but was 'Android Device'",
            "1: Must be a string starts with 'Smart', but was 'Apple Device'",
            "2: Must be a string starts with 'Smart', but was 'Stb Device'"
        ]

    @pytest.mark.parametrize("assert_function, errors_list", [
        (lambda r: r('devices').should(has_item("Web Device")), errors_list_1),
        (lambda r: r.should(has_entries(devices=has_item("Web Device"))), errors_list_1),
        (lambda r: r('devices').should(has_item(starts_with("Smart"))), errors_list_2),
        (lambda r: r.should(has_entries(devices=has_item(starts_with("Smart")))), errors_list_2),
    ])
    def test_list_has_item_matcher_for_simple_data_with_raises(self, doc_json, assert_function, errors_list):
        """Тесты на выдачу ошибки матчером `has_item`."""
        with pytest.raises(AssertionError) as excinfo:
            assert assert_function(doc_json)
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == len(errors_list)
        assert errors_list[0] in exeptions[0]
        assert errors_list[1] in exeptions[1]
        assert errors_list[2] in exeptions[2]
        assert errors_list[3] in exeptions[3]

    @pytest.mark.parametrize("assert_function, error_text", [
        (lambda r: r('devices').should(has_item_at_index(0, "Apple Device")), '0: Must be `Apple Device`, but was `Android Device`'),
        (lambda r: r('devices').should(has_item_at_index(-1, "Apple Device")), '2: Must be `Apple Device`, but was `Stb Device`'),
        (lambda r: r('devices').should(has_item_at_index(2, starts_with("Apple"))), "2: Must be a string starts with 'Apple', but was 'Stb Device'"),
        (lambda r: r('devices').should(has_first_item("Apple Device")), "0: Must be `Apple Device`, but was `Android Device`"),
        (lambda r: r('devices').should(has_last_item("Apple Device")), "2: Must be `Apple Device`, but was `Stb Device`"),
        (lambda r: r('devices').should(has_first_item(starts_with("Apple"))), "0: Must be a string starts with 'Apple', but was 'Android Device'"),
        (lambda r: r.should(has_entries(devices=has_item_at_index(0, "Apple Device"))), '0: Must be `Apple Device`, but was `Android Device`'),
        (lambda r: r.should(has_entries(devices=has_item_at_index(2, starts_with("Apple")))), "2: Must be a string starts with 'Apple', but was 'Stb Device'"),
        (lambda r: r.should(has_entries(devices=has_item_at_index(-3, starts_with("Apple")))), "0: Must be a string starts with 'Apple', but was 'Android Device'"),
        (lambda r: r.should(has_entries(devices=has_first_item("Apple"))), "0: Must be `Apple`, but was `Android Device`"),
        (lambda r: r.should(has_entries(devices=has_last_item(ends_with("Apple")))), "2: Must be a string ends with 'Apple', but was 'Stb Device'"),
    ])
    def test_list_has_item_at_index_matcher_for_simple_data_with_raises(self, doc_json, assert_function, error_text):
        """Тесты на выдачу ошибки матчером `has_item_at_index`."""
        with pytest.raises(AssertionError) as excinfo:
            assert assert_function(doc_json)
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 2
        assert 'devices: item at index' in exeptions[0]
        assert error_text in exeptions[1]

    @pytest.mark.parametrize("assert_function, error_index", [
        (lambda r: r('devices').should(has_item_at_index(3, "Apple Device")), '3'),
        (lambda r: r('devices').should(has_item_at_index(-4, "Apple Device")), '-4'),
        (lambda r: r.should(has_entries(devices=has_item_at_index(3, "Apple Device"))), '3'),
        (lambda r: r.should(has_entries(devices=has_item_at_index(-4, starts_with("Apple")))), "-4"),
    ])
    def test_list_has_item_at_index_matcher_for_simple_data_with_raises_by_index_error(self, doc_json, assert_function, error_index):
        """
        Тесты на выдачу ошибки матчером `has_item_at_index` в случаях когда в последовательности
        нет элемента с переданным индексом (IndexError).
        """
        with pytest.raises(AssertionError) as excinfo:
            assert assert_function(doc_json)
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 1
        assert f"devices: В списке нет элемента с индексом: {error_index}. Длинна списка 3" in exeptions[0]



class TestSequenceHasItemsMatcherForDicts:
    """ Тесты на работу валидатора `has_item` когда список содержит словарь """

    @pytest.mark.parametrize("matcher", [
        has_items(has_entries(title="Форсаж", id=750), has_entries(title="Форест Гамп", is_favorite=True)),
        has_items(has_entries(title=equal_to("Форсаж"), id=is_(750)), has_entries(title=equal_to("Форест Гамп"), is_favorite=is_(True))),
        has_items(has_entries(title=contains_string("приготовиться"), id=greater_than(999)), has_entries(title=starts_with("Форест")), has_entries(genres=has_length(greater_than(2)))),
    ])
    def test_list_has_item_matchers_for_dicts(self, doc_json, matcher):
        """ Тесты на матчер, позитивные и с отрицанием (список содержит словарь) """
        assert doc_json('media_items').should(matcher)
        assert doc_json.should(has_entries(media_items=matcher))
        assert doc_json.should(has_entries({"media_items": matcher}))

    errors_list_for_dicts_1 = [
        "media_items: any item",
        "0:",
        "id: Must be `1000`, but was `750`",
        "1:",
        "title: Must be `Форсаж`, but was `Первому игроку приготовиться`",
        "2:",
        "id: Must be `1000`, but was `50`",
        "title: Must be `Форсаж`, but was `Форест Гамп`",
    ]

    errors_list_for_dicts_2 = [
        "media_items: any item",
        "0:",
        "id: Must be greater than <1001> but was <750>",
        "title: Must be a string containing 'расслабиться', but was 'Форсаж'",
        "1:",
        "id: Must be greater than <1001> but was <1000>",
        "title: Must be a string containing 'расслабиться', but was 'Первому игроку приготовиться'",
        "2:",
        "id: Must be greater than <1001> but was <50>",
        "title: Must be a string containing 'расслабиться', but was 'Форест Гамп'",
    ]

    errors_list_for_dicts_3 = [
        "media_items: any item",
        "0:",
        "genres: Must has minimum length <5>, but was length is <2>. Object is: ['Фантастический фильм', 'Дизельный фильм']",
        "1:",
        "genres: Must has minimum length <5>, but was length is <2>. Object is: ['Фантастический фильм', 'Фильм по книге']",
        "2:",
        "genres: Must has minimum length <5>, but was length is <3>. Object is: ['Форест, беги', 'Спортивный фильм', 'Драма']",
    ]

    errors_list_for_dicts_4 = [
        "media_items: item at index=2:",
        "2:",
        "id: Must be `1000`, but was `50`",
        "title: Must be `Форсаж`, but was `Форест Гамп`",
   ]

    errors_list_for_dicts_5 = [
        "media_items: item at index=-1:",
        "2:",
        "genres: Must has minimum length <5>, but was length is <3>. Object is: [\'Форест, беги\', \'Спортивный фильм\', \'Драма\']"
    ]
    #
    # @pytest.mark.parametrize("assert_function, errors_list", [
    #     (lambda r: r('media_items').should(has_item(has_entries(title="Форсаж", id=1000))), errors_list_for_dicts_1),
    #     (lambda r: r.should(has_entries(media_items=has_item(has_entries(title="Форсаж", id=1000)))), errors_list_for_dicts_1),
    #
    #     (lambda r: r('media_items').should(has_item(has_entries(title=contains_string("расслабиться"), id=greater_than(1001)))), errors_list_for_dicts_2),
    #     (lambda r: r.should(has_entries(media_items=has_item(has_entries(title=contains_string("расслабиться"), id=greater_than(1001))))), errors_list_for_dicts_2),
    #
    #     (lambda r: r('media_items').should(has_item(has_entries(genres=has_length(greater_than(4))))), errors_list_for_dicts_3),
    #     (lambda r: r.should(has_entries(media_items=has_item(has_entries(genres=has_length(greater_than(4)))))), errors_list_for_dicts_3),
    #
    #     (lambda r: r('media_items').should(has_item_at_index(2, has_entries(title="Форсаж", id=1000))), errors_list_for_dicts_4),
    #     (lambda r: r.should(has_entries(media_items=has_item_at_index(2, has_entries(title="Форсаж", id=1000)))), errors_list_for_dicts_4),
    #
    #     (lambda r: r('media_items').should(has_item_at_index(-1, has_entries(genres=has_length(greater_than(4))))), errors_list_for_dicts_5),
    #     (lambda r: r.should(has_entries(media_items=has_last_item(has_entries(genres=has_length(greater_than(4)))))), errors_list_for_dicts_5),
    # ])
    # def test_list_has_item_matchers_for_dicts_with_raises(self, doc_json, assert_function, errors_list):
    #     """ Тесты на выдачу ошибки матчером """
    #     with pytest.raises(AssertionError) as excinfo:
    #         assert assert_function(doc_json)
    #     exeptions = parse_exeption(excinfo)
    #     assert len(exeptions) == len(errors_list)
    #     for index, error in enumerate(errors_list):
    #         assert error in exeptions[index]


