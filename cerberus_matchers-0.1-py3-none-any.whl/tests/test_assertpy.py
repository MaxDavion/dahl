from assertpy import  *

def test_iuytuyrt():
    assert_that().extracting()

