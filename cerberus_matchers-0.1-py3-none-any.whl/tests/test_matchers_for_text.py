from cerberus_matchers import *
import pytest
from tests.utils import parse_exeption


""" Тесты на работу text-валидаторов в схеме Cerberus с разными наборами данных """

@pytest.mark.parametrize("matcher", [
    starts_with("Твой"),
    ends_with("услуг"),
    contains_string("пакет"),
    string_contains_in_order("Твой", "услуг"),
    equal_to_ignoring_case("ТВОЙ ПАКЕТ УСЛУГ"),
    not_(starts_with("Мой")),
    not_(ends_with("услуги")),
    not_(contains_string("ПАКЕТ")),
    not_(string_contains_in_order("услуг", "Твой")),
    not_(equal_to_ignoring_case("ТВОЙ ПАКЕТ ПАКЕТОВ")),
])
def test_strings_matchers(doc_json, matcher):
    """ Тесты на матчер позитивные и с отрицанием """
    assert doc_json('name').should(matcher)
    assert doc_json.should(has_entries(name=matcher))
    assert doc_json.should(has_entries({"name": matcher}))


@pytest.mark.parametrize("matcher, error_text", [
    (starts_with("Мой"), "name: Must be a string starts with 'Мой', but was 'Твой пакет услуг'"),
    (ends_with("услуги"), "name: Must be a string ends with 'услуги', but was 'Твой пакет услуг'"),
    (contains_string("па кет"), "name: Must be a string containing 'па кет', but was 'Твой пакет услуг'"),
    (string_contains_in_order("услуг", "Твой"), "name: Must be a string containing ('услуг', 'Твой') in order, but was 'Твой пакет услуг'"),
    (equal_to_ignoring_case("ТВОЙ ПАКЕТ УСЛУГ2"), "name: Must be a string equal to 'ТВОЙ ПАКЕТ УСЛУГ2' ignoring case, but was 'Твой пакет услуг'"),
    (not_(starts_with("Твой")), "name: Must be a string not starts with 'Твой', but was 'Твой пакет услуг'"),
    (not_(ends_with("услуг")), "name: Must be a string not ends with 'услуг', but was 'Твой пакет услуг'"),
    (not_(contains_string("пакет")), "name: Must be a string not containing 'пакет', but was 'Твой пакет услуг'"),
    (not_(equal_to_ignoring_case("ТВОЙ ПАКЕТ УСЛУГ")), "name: Must be a string not equal to 'ТВОЙ ПАКЕТ УСЛУГ' ignoring case, but was 'Твой пакет услуг'"),
    (not_(string_contains_in_order("Твой", "услуг")), "name: Must be a string not containing ('Твой', 'услуг') in order, but was 'Твой пакет услуг'"),
])
def test_text_matchers_with_raises(doc_json, matcher, error_text):
    """ Тесты на выдачу ошибки матчером """
    with pytest.raises(AssertionError) as excinfo:
        assert doc_json('name').should(matcher)
    exeptions = parse_exeption(excinfo)
    assert len(exeptions) == 1
    assert error_text in exeptions[0]

    with pytest.raises(AssertionError) as excinfo:
        assert doc_json.should(has_entries(name=matcher))
    exeptions = parse_exeption(excinfo)
    assert len(exeptions) == 1
    assert error_text in exeptions[0]

    with pytest.raises(AssertionError) as excinfo:
        assert doc_json.should(has_entries({"name":matcher}))
    exeptions = parse_exeption(excinfo)
    assert len(exeptions) == 1
    assert error_text in exeptions[0]







