import pytest
from cerberus_matchers import *
from tests.utils import parse_exeption


""" Тесты на матчеры объединяющие нескольких утверждений в одном, all_of, any_of """


class TestAllOfMatcher:
    """ Тесты на работу валидаторов совместно в режиме `all_of` """

    @pytest.mark.parametrize("matcher", [
        has_entries(id=all_of(greater_than(300), less_than(9000000))),
        has_entries(name=all_of(starts_with("Твой"), ends_with("услуг"), instance_of(str))),
        has_entries(devices=all_of(has_item("Android Device"), has_item("Stb Device"), has_length(3))),
        has_entries(raitings=all_of(has_key("kinopoisk"), has_key("wink"))),
        has_entries(media_items=has_item(has_entries(id=all_of(greater_than(300), less_than(9000000)))))
    ])
    def test_all_of_matcher(self, doc_json, matcher):
        """ Тесты на матчер all_of() """
        assert doc_json.should(matcher)

    def test_all_of_matcher_with_raises_1(self, doc_json):
        """ есты на выдачу ошибки матчером all_of() """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json.should(has_entries(id=all_of(greater_than(1234567), less_than(90000000))))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 2
        assert "id: one or more definitions don't validate" in exeptions[0]
        assert "allof definition 0: Must be greater than <1234567> but was <123456>" in exeptions[1]

    def test_all_of_matcher_with_raises_2(self, doc_json):
        """ есты на выдачу ошибки матчером all_of() """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json.should(has_entries(id=all_of(greater_than(300), less_than(9))))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 2
        assert "id: one or more definitions don't validate" in exeptions[0]
        assert "allof definition 1: Must be less than <9> but was <123456>" in exeptions[1]

    def test_all_of_matcher_with_raises_3(self, doc_json):
        """ есты на выдачу ошибки матчером all_of() """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json.should(has_entries(id=all_of(greater_than(1234567), less_than(9))))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 3
        assert "id: one or more definitions don't validate" in exeptions[0]
        assert "allof definition 0: Must be greater than <1234567> but was <123456>" in exeptions[1]
        assert "allof definition 1: Must be less than <9> but was <123456>" in exeptions[2]

    def test_all_of_matcher_with_raises_4(self, doc_json):
        """ есты на выдачу ошибки матчером all_of() """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json.should(has_entries(name=all_of(starts_with("Ошибка"), ends_with("услуг"), instance_of(str))))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 2
        assert "name: one or more definitions don't validate" in exeptions[0]
        assert "allof definition 0: Must be a string starts with 'Ошибка', but was 'Твой пакет услуг'" in exeptions[1]

    def test_all_of_matcher_with_raises_5(self, doc_json):
        """ Тесты на выдачу ошибки матчером all_of() """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json.should(has_entries(name=all_of(starts_with("Твой"), ends_with("услуг"), instance_of(bool))))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 2
        assert "name: one or more definitions don't validate" in exeptions[0]
        assert "allof definition 2: must be of boolean type" in exeptions[1]

    def test_all_of_matcher_with_raises_6(self, doc_json):
        """ Тесты на выдачу ошибки матчером all_of() """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json.should(has_entries(devices=all_of(has_item("Неизвестно Device"), has_item("Stb Device"), has_length(4))))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 6
        assert "devices: one or more definitions don't validate" in exeptions[0]
        assert "allof definition 0: any item" in exeptions[1]
        assert "0: Must be `Неизвестно Device`, but was `Android Device`" in exeptions[2]
        assert "1: Must be `Неизвестно Device`, but was `Apple Device`" in exeptions[3]
        assert "2: Must be `Неизвестно Device`, but was `Stb Device`" in exeptions[4]
        assert "allof definition 2: Must has length <4>, but was length is <3>. Object is: ['Android Device', 'Apple Device', 'Stb Device']" in exeptions[5]

    def test_all_of_matcher_with_raises_7(self, doc_json):
        """ Тесты на выдачу ошибки матчером all_of() """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json.should(has_entries(raitings=all_of(has_key("unknow"), has_key("wink"))))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 2
        assert "raitings: one or more definitions don't validate" in exeptions[0]
        assert "allof definition 0: Must has key `unknow`, but was `{'kinopoisk': 8.9, 'imdb': 9.1, 'wink': 9.5}`" in exeptions[1]

    def test_all_of_matcher_with_raises_8(self, doc_json):
        """ Тесты на выдачу ошибки матчером all_of() """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json.should(has_entries(
                media_items=has_item(has_entries(
                    id=all_of(greater_than(300000000), less_than(9))))))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 13
        assert "media_items: any item" in exeptions[0]
        assert "0:" in exeptions[1]
        assert "id: one or more definitions don't validate" in exeptions[2]
        assert "allof definition 0: Must be greater than <300000000> but was <750>" in exeptions[3]
        assert "allof definition 1: Must be less than <9> but was <750>" in exeptions[4]
        assert "1:" in exeptions[5]
        assert "id: one or more definitions don't validate" in exeptions[6]
        assert "allof definition 0: Must be greater than <300000000> but was <1000>" in exeptions[7]
        assert "allof definition 1: Must be less than <9> but was <1000>" in exeptions[8]
        assert "2:" in exeptions[9]
        assert "id: one or more definitions don't validate" in exeptions[10]
        assert "allof definition 0: Must be greater than <300000000> but was <50>" in exeptions[11]
        assert "allof definition 1: Must be less than <9> but was <50>" in exeptions[12]



class TestAnyOfMatcher:
    """ Тесты на работу валидаторов совместно в режиме `any_of` """

    @pytest.mark.parametrize("matcher", [
        has_entries(id=any_of(greater_than(300), less_than(9))),
        has_entries(id=any_of(greater_than(3), less_than(9000000))),
        has_entries(name=any_of("Неверно", "Твой пакет услуг")),
        has_entries(name=any_of(equal_to("Твой пакет услуг"), equal_to("Неверно"))),
        has_entries(name=any_of(starts_with("Неверно"), ends_with("услуг"), instance_of(str))),
        has_entries(name=any_of(starts_with("Неверно"), ends_with("услуг"), instance_of(int))),
        has_entries(devices=any_of(has_item("Android Device"), has_item("Stb Device"), has_length(5))),
        has_entries(devices=any_of(has_item("Неверно"), has_item("Stb Device"), has_length(5))),
        has_entries(raitings=any_of(has_key("Неверно"), has_key("wink"))),
        has_entries(raitings=any_of(has_key("kinopoisk"), has_key("Неверно"))),
        has_entries(media_items=has_item(has_entries(id=any_of(greater_than(3), less_than(9000000))))),
        has_entries(media_items=has_item(has_entries(id=any_of(greater_than(300), less_than(9)))))
    ])
    def test_any_of_matcher(self, doc_json, matcher):
        """ Тесты на матчер any_of() """
        assert doc_json.should(matcher)

    def test_any_of_matcher_with_raises_1(self, doc_json):
        """ Тесты на выдачу ошибки матчером """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json.should(has_entries(id=any_of(greater_than(12345600), less_than(9))))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 3
        assert "id: no definitions validate" in exeptions[0]
        assert "anyof definition 0: Must be greater than <12345600> but was <123456>" in exeptions[1]
        assert "anyof definition 1: Must be less than <9> but was <123456>" in exeptions[2]

    def test_any_of_matcher_with_raises_2(self, doc_json):
        """ Тесты на выдачу ошибки матчером """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json.should(has_entries(name=any_of("Неверно1", "Неверно2")))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 3
        assert "name: no definitions validate" in exeptions[0]
        assert "anyof definition 0: Must be `Неверно1`, but was `Твой пакет услуг`" in exeptions[1]
        assert "anyof definition 1: Must be `Неверно2`, but was `Твой пакет услуг`" in exeptions[2]

    def test_any_of_matcher_with_raises_3(self, doc_json):
        """ Тесты на выдачу ошибки матчером """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json.should(has_entries(name=any_of(starts_with("Неверно"), ends_with("Неверно"), instance_of(list))))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 4
        assert "name: no definitions validate" in exeptions[0]
        assert "anyof definition 0: Must be a string starts with 'Неверно', but was 'Твой пакет услуг'" in exeptions[1]
        assert "anyof definition 1: Must be a string ends with 'Неверно', but was 'Твой пакет услуг'" in exeptions[2]
        assert "anyof definition 2: must be of list type" in exeptions[3]

    def test_any_of_matcher_with_raises_4(self, doc_json):
        """ Тесты на выдачу ошибки матчером """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json.should(has_entries(
                devices=any_of(has_item("Неверно Device"), has_item("Неверно2 Device"), has_length(8))))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 10
        assert "devices: no definitions validate" in exeptions[0]
        assert "anyof definition 0: any item" in exeptions[1]
        assert "0: Must be `Неверно Device`, but was `Android Device`" in exeptions[2]
        assert "1: Must be `Неверно Device`, but was `Apple Device`" in exeptions[3]
        assert "2: Must be `Неверно Device`, but was `Stb Device`" in exeptions[4]
        assert "anyof definition 1: any item" in exeptions[5]
        assert "0: Must be `Неверно2 Device`, but was `Android Device`" in exeptions[6]
        assert "1: Must be `Неверно2 Device`, but was `Apple Device`" in exeptions[7]
        assert "2: Must be `Неверно2 Device`, but was `Stb Device`" in exeptions[8]
        assert "anyof definition 2: Must has length <8>, but was length is <3>. Object is: ['Android Device', 'Apple Device', 'Stb Device']" in exeptions[9]

    def test_any_of_matcher_with_raises_5(self, doc_json):
        """ Тесты на выдачу ошибки матчером """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json.should(has_entries(raitings=any_of(has_key("unknow1"), has_key("unknow2"))))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 3
        assert "raitings: no definitions validate" in exeptions[0]
        assert "anyof definition 0: Must has key `unknow1`, but was `{'kinopoisk': 8.9, 'imdb': 9.1, 'wink': 9.5}`" in exeptions[1]
        assert "anyof definition 1: Must has key `unknow2`, but was `{'kinopoisk': 8.9, 'imdb': 9.1, 'wink': 9.5}`" in exeptions[2]

