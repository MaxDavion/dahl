from cerberus_matchers import *
import pytest
from tests.utils import parse_exeption


""" Тесты на работу empty-валидатора в схеме Cerberus с разными наборами данных """


@pytest.mark.parametrize("matcher", [
    has_entries(stars=none()),
    has_entries(stars=None),
    has_entries(stars=is_(None)),
    has_entries(id=not_none()),
    has_entries(id=not_(None))
])
def test_none_matcher(doc_json, matcher):
    " Тесты на матчер позитивные и негативные """
    assert doc_json.should(matcher)


@pytest.mark.parametrize("matcher", [
    has_entries(id=none()),
    has_entries(id=None),
    has_entries(id=is_(None)),
])
def test_none_matcher_with_raises(doc_json, matcher):
    """ Тесты на выдачу ошибки матчером (позитивные сценарии) """
    with pytest.raises(AssertionError) as excinfo:
        assert doc_json.should(matcher)
    exeptions = parse_exeption(excinfo)
    assert len(exeptions) == 1
    assert "id: Must be `None`, but was `123456`" in exeptions[0]


@pytest.mark.parametrize("matcher", [
    has_entries(stars=not_none()),
    has_entries(stars=not_(None)),
])
def test_none_matcher_with_raises_for_negative(doc_json, matcher):
    """ Тесты на выдачу ошибки матчером (негативные сценарии) """
    with pytest.raises(AssertionError) as excinfo:
        assert doc_json.should(matcher)
    exeptions = parse_exeption(excinfo)
    assert len(exeptions) == 2
    assert "stars: Must be not `None`, but was `None`" in exeptions[0]

