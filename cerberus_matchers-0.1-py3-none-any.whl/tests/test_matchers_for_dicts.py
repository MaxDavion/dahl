from cerberus_matchers import *
import pytest
from tests.utils import parse_exeption


""" Тесты на работу dict-валидаторов в схеме Cerberus с разными наборами данных """


class TestHasKeyMatcher:
    """ Тесты на обработку hamcrest-матчера has_key() в cerberus """

    @pytest.mark.parametrize("matcher", [
        has_key("kinopoisk"),
        has_key(equal_to("kinopoisk")),
        # has_key(starts_with("kinopoisk")),
        not_(has_key("kinop oisk"))
    ])
    def test_has_key_matcher(self, doc_json, matcher):
        """ Тесты на матчер позитивные и с отрицанием """
        assert doc_json('raitings').should(matcher)
        assert doc_json.should(has_entries(raitings=matcher))
        assert doc_json.should(has_entries({"raitings": matcher}))

    @pytest.mark.parametrize("matcher, error_text", [
        (has_key("kino poisk"), "raitings: Must has key `kino poisk`, but was `{'kinopoisk': 8.9, 'imdb': 9.1, 'wink': 9.5}`"),
        (has_key(equal_to("kino poisk")), "raitings: Must has key `kino poisk`, but was `{'kinopoisk': 8.9, 'imdb': 9.1, 'wink': 9.5}`"),
        (not_(has_key("kinopoisk")), "raitings: Must not has key `kinopoisk`, but was `{'kinopoisk': 8.9, 'imdb': 9.1, 'wink': 9.5}`"),
    ])
    def test_has_key_matcher_with_raises(self, doc_json, matcher, error_text):
        """ Тесты на выдачу ошибки матчером """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json('raitings').should(matcher)
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 1
        assert error_text in exeptions[0]

        with pytest.raises(AssertionError) as excinfo:
            assert doc_json.should(has_entries(raitings=matcher))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 1
        assert error_text in exeptions[0]

        with pytest.raises(AssertionError) as excinfo:
            assert doc_json.should(has_entries({"raitings": matcher}))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 1
        assert error_text in exeptions[0]


class TestHasValueMatcher:
    """ Тесты на запрет hamcrest-матчера has_value() в cerberus """

    def test_forbidden_has_value_matcher(self, doc_json):
        with pytest.raises(Exception) as excinfo:
            assert doc_json.should(has_entries(raitings=has_value(8.9)))
        assert "Матчер `has_value()` еще не портирован в Cerberus-формат" in str(excinfo)

        with pytest.raises(Exception) as excinfo:
            assert doc_json("raitings").should(has_value(8.9))
        assert "Матчер `has_value()` еще не портирован в Cerberus-формат" in str(excinfo)


class TestHasEntryMatcher:
    """ Тесты на запрет hamcrest-матчера has_entry() в cerberus """

    def test_forbidden_has_entry_matcher(self, doc_json):
        with pytest.raises(Exception) as excinfo:
            assert doc_json.should(has_entries(raitings=has_entry("kinopoisk", 8.9)))
        assert "Матчер `has_entry()` не портирован в Cerberus-формат. Это можно сделать, но в большинстве случаев " \
               "лучше использовать матчер `has_entries()`" in str(excinfo)

        with pytest.raises(Exception) as excinfo:
            assert doc_json("raitings").should(has_entry("kinopoisk", 8.9))
        assert "Матчер `has_entry()` не портирован в Cerberus-формат. Это можно сделать, но в большинстве случаев " \
               "лучше использовать матчер `has_entries()`" in str(excinfo)


class TestHasEntriesMatcher:
    """ Тесты на обработку hamcrest-матчера has_entries() в cerberus """

    @pytest.mark.parametrize("matcher", [
        has_entries(kinopoisk=8.9, wink=equal_to(9.5)),
        has_entries(kinopoisk=is_(float), wink=greater_than(8.9)),
        has_entries({"kinopoisk": is_(float), "wink": greater_than(8.9)}),
        has_entries(kinopoisk=not_(9.4), wink=not_(equal_to(10.0))),
        # not_(has_entries(kinopoisk=3.9))
    ])
    def test_has_entries_matcher(self, doc_json, matcher):
        """ Тесты на матчер позитивные и с отрицанием """
        assert doc_json('raitings').should(matcher)
        assert doc_json.should(has_entries(raitings=matcher))
        assert doc_json.should(has_entries({"raitings": matcher}))

    @pytest.mark.parametrize("assert_function", [
        lambda r: r('raitings').should(has_entries(kinopoisk=9.0, imdb=greater_than(9.11), wink=is_(int))),
        lambda r: r.should(has_entries(raitings=has_entries(kinopoisk=9.0, imdb=greater_than(9.11), wink=is_(int)))),
        lambda r: r.should(
            has_entries({"raitings": has_entries(kinopoisk=9.0, imdb=greater_than(9.11), wink=is_(int))})),
        # lambda r: r.should(
        #     has_entries({"raitings": has_entries({"kinopoisk": 9.0}, {"imdb": greater_than(9.11)}, wink=is_(int))})),
    ])
    def test_has_entries_matcher_with_raises(self, doc_json, assert_function):
        """ Тесты на выдачу ошибки матчером """
        with pytest.raises(AssertionError) as excinfo:
            assert assert_function(doc_json)
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 4
        assert "raitings:" in exeptions[0]
        assert "imdb: Must be greater than <9.11> but was <9.1>" in exeptions[1]
        assert "kinopoisk: Must be `9.0`, but was `8.9`" in exeptions[2]
        assert "wink: must be of integer type" in exeptions[3]


class TestDeepInnerDictsMatchers:
    """ Матчеры на проверки вложенных словарей """

    @pytest.fixture(scope='class')
    def doc_json(self):
        return AssertableDict({
            "inner_dict1": {
                "key1": "value1",
                "inner_dict2": {
                    "key2": "value2",
                    "inner_dict3": {
                        "key3": 15,
                        "key4": "value4"
                    }
                }
            }
        })

    def test_deep_3th_level_has_entries_matcher(self, doc_json):
        """ Тесты на матчер c глубоким вложением словарей """
        assert doc_json.should(has_entries(
            inner_dict1=has_entries(
                key1="value1",
                inner_dict2=has_entries(
                    key2=starts_with("value"),
                    inner_dict3=has_entries(
                        key3=greater_than(14),
                        key4=equal_to("value4")
                    )
                )
            )
        )
    )

    def test_deep_3th_level_has_entries_matcher_with_raises(self, doc_json):
        """ Тесты на выдачу ошибки при глубоким вложением словарей """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json.should(has_entries(
                inner_dict1=has_entries(
                    key1="value11",
                    inner_dict2=has_entries(
                        key22=starts_with("value"),
                        inner_dict3=has_entries(
                            key3=greater_than(15),
                            key4=equal_to("value44")
                        )
                    )
                )
            )
        )

        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 7
        assert "inner_dict1:" in exeptions[0]
        assert "inner_dict2" in exeptions[1]
        assert "inner_dict3" in exeptions[2]
        assert "key3: Must be greater than <15> but was <15>" in exeptions[3]
        assert "key4: Must be `value44`, but was `value4`" in exeptions[4]
        assert "key22: required field" in exeptions[5]
        assert "key1: Must be `value11`, but was `value1" in exeptions[6]
