from cerberus_matchers import *
import pytest
from tests.utils import parse_exeption


""" Тесты на работу валидаторов длинны сущности в схеме Cerberus с разными наборами данных 
    * Под сущностью понимается любая сущность, которая ссодержит __len__ : lsit, str, tuple, dict  и пр.
"""

class TestHasLengthMatcher:
    """ Тесты на работу валидатора проверки длинны в схеме Cerberus с разными наборами данных """

    @pytest.mark.parametrize("matcher", [
        has_length(3),
        has_length(equal_to(3)),
        has_length(greater_than(2)),
        has_length(greater_than_or_equal_to(3)),
        has_length(less_than(4)),
        has_length(less_than_or_equal_to(3)),
        not_(has_length(4)),
        # not_(has_length(less_than(4))),
        # has_length(not_(less_than(4))),
    ])
    def test_list_has_length_matchers(self, doc_json, doc_list, matcher):
        """ Тесты на матчер позитивные и с отрицанием (с типом даннных list) """
        assert doc_json('devices').should(matcher)
        assert doc_json.should(has_entries(devices=matcher))
        assert doc_json.should(has_entries({"devices": matcher}))

        assert doc_list.should(matcher)

    def test_other_sequence_type_length_matchers(self, doc_json):
        """ Тесты на матчер позитивные и с отрицанием (с типом даннных  str и dict) """
        assert doc_json.should(has_entries(name=has_length(16), raitings=has_length(3)))
        assert doc_json.should(has_entries(name=has_length(greater_than(15)), raitings=has_length(greater_than(2))))

    @pytest.mark.parametrize("matcher, error_text", [
        (has_length(2), "devices: Must has length <2>, but was length is <3>. Object is: ['Android Device', 'Apple Device', 'Stb Device']"),
        (has_length(equal_to(2)), "devices: Must has length <2>, but was length is <3>. Object is: ['Android Device', 'Apple Device', 'Stb Device']"),
        (has_length(greater_than(3)), "devices: Must has minimum length <4>, but was length is <3>. Object is: ['Android Device', 'Apple Device', 'Stb Device']"),
        (has_length(greater_than_or_equal_to(4)), "devices: Must has minimum length <4>, but was length is <3>. Object is: ['Android Device', 'Apple Device', 'Stb Device']"),
        (has_length(less_than(3)), "devices: Must has maximum length <2>, but was length is <3>. Object is: ['Android Device', 'Apple Device', 'Stb Device']"),
        (has_length(less_than_or_equal_to(2)), "* devices: Must has maximum length <2>, but was length is <3>. Object is: ['Android Device', 'Apple Device', 'Stb Device']"),
        (not_(has_length(3)), "devices: Must has length not <3>, but was length is <3>. Object is: ['Android Device', 'Apple Device', 'Stb Device']"),
     ])
    def test_list_has_length_matchers_with_raises(self, doc_json, matcher, error_text):
        """ Тесты на выдачу ошибки матчером """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json('devices').should(matcher)
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 1
        assert error_text in exeptions[0]

        with pytest.raises(AssertionError) as excinfo:
            assert doc_json.should(has_entries(devices=matcher))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 1
        assert error_text in exeptions[0]

        with pytest.raises(AssertionError) as excinfo:
            assert doc_json.should(has_entries({"devices": matcher}))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 1
        assert error_text in exeptions[0]

    def test_list_has_length_matchers_with_raises_2(self, doc_list):
        """ Тесты на выдачу ошибки матчером (когда документ это список)"""
        with pytest.raises(AssertionError) as excinfo:
            assert doc_list.should(has_length(2))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 1
        assert 'Must has length <2>, but was length is <3>' in exeptions[0]


class TestEmptyMatcher:
    """ Тесты на работу empty-валидатора в схеме Cerberus с разными наборами данных """

    @pytest.fixture(scope='class')
    def doc_json(self):
        return AssertableDict({
            "empty_list": [],
            "not_empty_list": [1, 2, 3]
        })

    @pytest.mark.parametrize("matcher", [
        empty(),
        is_(empty())
    ])
    def test_list_has_length_matchers(self, doc_json, matcher):
        """ Тесты на матчер позитивные """
        assert doc_json('empty_list').should(matcher)
        assert doc_json.should(has_entries(empty_list=matcher))
        assert doc_json.should(has_entries({"empty_list": matcher}))

    @pytest.mark.parametrize("matcher", [
        not_(empty()),
        is_(not_(empty())),
    ])
    def test_list_has_length_matchers_woth_not(self, doc_json, matcher):
        """ Тесты на матчер c отрицанием """
        assert doc_json('not_empty_list').should(matcher)
        assert doc_json.should(has_entries(not_empty_list=matcher))
        assert doc_json.should(has_entries({"not_empty_list": matcher}))

    @pytest.mark.parametrize("matcher, error_text", [
        (empty(), "not_empty_list: Must has length <0>, but was length is <3>. Object is: [1, 2, 3]"),
        (is_(empty()), "not_empty_list: Must has length <0>, but was length is <3>. Object is: [1, 2, 3]"),
    ])
    def test_empty_matcher_with_raises1(self, doc_json, matcher, error_text):
        """ Тесты на выдачу ошибки матчером (позитивнные) """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json('not_empty_list').should(matcher)
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 1
        assert error_text in exeptions[0]

        with pytest.raises(AssertionError) as excinfo:
            assert doc_json.should(has_entries(not_empty_list=matcher))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 1
        assert error_text in exeptions[0]

        with pytest.raises(AssertionError) as excinfo:
            assert doc_json.should(has_entries({"not_empty_list": matcher}))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 1
        assert error_text in exeptions[0]

    @pytest.mark.parametrize("matcher, error_text", [
        (not_(empty()), "empty_list: Must has length not <0>, but was length is <0>. Object is: []"),
        (is_(not_(empty())), "empty_list: Must has length not <0>, but was length is <0>. Object is: []"),
    ])
    def test_empty_matcher_with_raises2(self, doc_json, matcher, error_text):
        """ Тесты на выдачу ошибки матчером (отрицательные) """
        with pytest.raises(AssertionError) as excinfo:
            assert doc_json('empty_list').should(matcher)
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 1
        assert error_text in exeptions[0]

        with pytest.raises(AssertionError) as excinfo:
            assert doc_json.should(has_entries(empty_list=matcher))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 1
        assert error_text in exeptions[0]

        with pytest.raises(AssertionError) as excinfo:
            assert doc_json.should(has_entries({"empty_list": matcher}))
        exeptions = parse_exeption(excinfo)
        assert len(exeptions) == 1
        assert error_text in exeptions[0]
