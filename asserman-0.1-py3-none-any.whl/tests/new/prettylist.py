import prettylist

# https://github.com/mohansom/prettylist

# https://github.com/kevink1103/pyprnt
# https://github.com/smeggingsmegger/VeryPrettyTable
# https://github.com/adamlamers/prettytable
# https://github.com/warfares/pretty-json
# https://github.com/onelivesleft/PrettyErrors