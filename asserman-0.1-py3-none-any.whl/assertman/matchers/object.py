import hamcrest


equal_to = hamcrest.equal_to
has_length = hamcrest.has_length
instance_of = hamcrest.instance_of
none = hamcrest.none
not_none = hamcrest.not_none
same_instance = hamcrest.same_instance
is_ = hamcrest.is_

