from assertman.assertable_mixin import AssertableMixin


class AssertableDict(dict, AssertableMixin):
    _assertion_processing = "cerberus"

    @property
    def _assertable_data(self):
        return self

    def __call__(self, query):
        return self.__class__(self).extract(query)



