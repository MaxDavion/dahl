from assertman.assertable_mixin import AssertableMixin


class AssertableList(list, AssertableMixin):
    _assertion_processing = "hamcrest"

    @property
    def _assertable_data(self):
        return self
